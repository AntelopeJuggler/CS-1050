#include <stdio.h>

int reset_day(void);
int record_purchase(int cents);
int compute_points(int cents);
int get_total_points(void);
int redeem_reward(int points_needed);
int bonus_points_day(int multiplier);